angular.module('app.controllers', [])
  
.controller('parentActivityCtrl', function($scope) {

})
   
.controller('homeActivitesCtrl', function($scope) {

})
   
.controller('cloudTabDefaultPageCtrl', function($scope) {

})
      
.controller('rEGISTRATIONCtrl', function($scope) {

})
   
.controller('fLIPKITCtrl', function($scope) {

})
   
.controller('flipKitSurvayCtrl', function($scope) {

})
 
.controller('categoryCtrl', function($scope) {

})

.controller('homepageCtrl', function($scope) {

})

.controller('FlipKitSelectionCtrl', function($scope) {

})
.controller('tabsControllerCtrl', function($scope) {

})
 